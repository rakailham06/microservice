package com.raka.order.vo;

public class Produk {
  private Long id;
  private String nama;
  private String satuan;
  private double harga;
}


